package com.gson.exoservice;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;


public class ExoService extends Activity {
	
	public MediaPlayer play;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exo_service);
        Button btns =(Button) findViewById(R.id.btnstart);
        Button btnp =(Button) findViewById(R.id.btnstop);
        
        btns.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				onCreate();
				
			}
		});
        
        btnp.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				onDestroy();
				
			}
		});
        
    }


    protected void onCreate() {
		// TODO Auto-generated method stub
    	Toast.makeText(this, "Service Started", Toast.LENGTH_LONG).show();
    	play= MediaPlayer.create(this, R.raw.so_bad);
    	play.setLooping(false);
    	play.start();
		
	}


	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.exo, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    	
    
    public void onDestroy(){
    	Toast.makeText(this, "Service Stoped", Toast.LENGTH_LONG).show();
    	play.stop();
    	
    }
}
