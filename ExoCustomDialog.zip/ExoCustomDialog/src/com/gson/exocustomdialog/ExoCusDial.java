package com.gson.exocustomdialog;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


public class ExoCusDial extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exo_cus_dial);
        
        Button btngo = (Button) findViewById(R.id.btnshow);
        btngo.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				final Dialog mydia = new Dialog(ExoCusDial.this);
				mydia.setContentView(R.layout.mydialog);
				mydia.setTitle("G CUSTOM DIALOG");
				mydia.setCancelable(true);
				mydia.show();
				final EditText tname = (EditText) mydia.findViewById(R.id.name);
				ImageView imgv = (ImageView) mydia.findViewById(R.id.img);
				imgv.setImageResource(R.drawable.ic_launcher);
				
				Button btnubmit = (Button) mydia.findViewById(R.id.btnsub);
				Button btcancel = (Button) mydia.findViewById(R.id.btncanc);
				
				
				btnubmit.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Toast.makeText(getApplicationContext(), tname.getText().toString(), Toast.LENGTH_LONG ).show();
					}
				});
				
				
				btcancel.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						mydia.cancel();
						
					}
				});
				
				
				
				
			}
		});
        
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.exo_cus_dial, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
